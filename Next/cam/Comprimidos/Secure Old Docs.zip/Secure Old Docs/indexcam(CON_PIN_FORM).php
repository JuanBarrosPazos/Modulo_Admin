<?php

	//require '../Inclu/error_hidden.php';
	require '../Conections/conection.php';
	require '../Conections/conect.php';

	unset($_SESSION['usuarios']);
	require '../Inclu/misdatos.php';
?>

<!DOCTYPE html>
<html>
	
<head>

<meta http-equiv="content-type" content="text/html" charset="<?php print($meta_type_charset);?>" />
<meta http-equiv="Content-Language" content="<?php print($meta_lang_cotent2);?>" />
<meta name="Language" content="<?php print($meta_lang_cotent);?>" />
<meta name="description" content="<?php print($meta_desc_cotent);?>" />
<meta name="keywords" content="<?php print($meta_key_cotent);?>" />
<meta name="robots" content="<?php print($meta_robots_cotent);?>" />
<meta name="audience" content="<?php print($meta_audience_cotent);?>" />
<title><?php print($meta_titulo);?></title>
	
<link href="../Css/conta.css" rel="stylesheet" type="text/css" />
<link href="../Css/menu.css" rel="stylesheet" type="text/css" />
<link href="../Css/menuico.css" rel="stylesheet" type="text/css" />

<link href="../Images/favicon.ico" type='image/ico' rel='shortcut icon' />

<script type="text/javascript">

 function hora(){
 var fecha = new Date()
 
 var diames = fecha.getDate()

 var daytext = fecha.getDay()
 if (daytext == 0)
 daytext = "Domingo"
 else if (daytext == 1)
 daytext = "Lunes"
 else if (daytext == 2)
 daytext = "Martes"
 else if (daytext == 3)
 daytext = "Miercoles"
 else if (daytext == 4)
 daytext = "Jueves"
 else if (daytext == 5)
 daytext = "Viernes"
 else if (daytext == 6)
 daytext = "Sabado"
 
 var mes = fecha.getMonth() + 1
 
 var ano = fecha.getYear()
 
 if (fecha.getYear() < 2000) 
 ano = 1900 + fecha.getYear()
 else 
 ano = fecha.getYear()
 
 var hora = fecha.getHours()
 var minuto = fecha.getMinutes()
 var segundo = fecha.getSeconds()
 
 if(hora>=12 && hora<=23)
 m="P.M"
 else
 m="A.M"
 
 if (hora < 10) {hora = "0" + hora}
 if (minuto < 10) {minuto = "0" + minuto}
 if (segundo < 10) {segundo = "0" + segundo}
 
 var nowhora = daytext + " " + diames + " / " + mes + " / " + ano + " - " + hora + ":" + minuto + ":" + segundo
 document.getElementById('hora').firstChild.nodeValue = nowhora
 tiempo = setTimeout('hora()',1000)
 }
	
</script>
	
<!--	
<style>
/* INICIO ESTILOS VENTANA FLOTANTE
	JUANBARROSPAZOS.BLOGSPOT*/

#ventana-flotante {
width: 400px;  /* Ancho de la ventana */
height: 80px;  /* Alto de la ventana */
background: #E4F1F1;  /* Color de fondo */
position: fixed;
top: 38%;
left: 16%;
margin-left: -180px;
border: 1px solid #408080;  /* Borde de la ventana */
box-shadow: 0 5px 25px rgba(0,0,0,.1);  /* Sombra */
z-index:999;
}
#ventana-flotante .cerrar {
float: right;
border-bottom: 1px solid #408080;
border-left: 1px solid #408080;
color: #990000;
background: #E4F1F1;
line-height: 17px;
text-decoration: none;
padding: 0px 14px;
font-family: Arial;
border-radius: 0 0 0 5px;
box-shadow: -1px 1px white;
font-size: 18px;
-webkit-transition: .3s;
-moz-transition: .3s;
-o-transition: .3s;
-ms-transition: .3s;
}
#ventana-flotante .cerrar:hover {
background: #990000;
color: white;
text-decoration: none;
text-shadow: -1px -1px #990000;;
border-bottom: 1px solid #990000;;
border-left: 1px solid #990000;;
}
#ventana-flotante .contenido {
padding: 15px;
box-shadow: inset 1px 1px white;
/*background: #deffc4;   Fondo del mensaje */
/*border: 1px solid #9eff9e;   Borde del mensaje */
font-size: 18px;  /* Tamaño del texto del mensaje */
color: #555;  /* Color del texto del mensaje */
text-shadow: 1px 1px white;
margin: 0 auto;
border-radius: 4px;
}
#ventana-flotante a {
	color: #666;
	text-decoration: none;
}
#ventana-flotante a:hover {
	color: #990000;
	text-decoration: none;
}

.oculto {-webkit-transition:1s;-moz-transition:1s;-o-transition:1s;-ms-transition:1s;opacity:0;-ms-opacity:0;-moz-opacity:0;visibility:hidden;}

/* FLOTANTE CAMARA INDEXCAM */
.camara0{
	width: 304px;
	height: 230px;
	text-align: center;
	margin-left: auto;
	margin-right: auto;
	margin-top: 4px;
	border: medium double #CCC;
	padding: 0px;
}
.camara{
	width: 300px;
	height: 230px;
	/*
	width: 433px;
	height: 324px;
	width: 640px;
	height: 480px;
	*/
	margin: 0px;
	padding: 0px;
}
/* FIN ESTILOS VENTANA FLOTANTE*/
</style>
-->
<!--  
	<meta http-equiv="Refresh" content="20;url=indexcam.php">
-->

					<!-- *************************** -->
<!-- *************************** -->		<!-- *************************** -->
					<!-- *************************** -->
	
  	<script src="jquery-1.11.3.min.js"></script>
	
					<!-- *************************** -->
<!-- *************************** -->		<!-- *************************** -->
					<!-- *************************** -->
	
</head>

<body topmargin="0" onload="hora()">

<!--
<div id='ventana-flotante'>
   <a class='cerrar' href='javascript:void(0);' onclick='document.getElementById(&apos;ventana-flotante&apos;).className = &apos;oculto&apos;'>X</a>
-->
        <!--[if IE]>
        <style>
        .oculto {display:none}
        </style>
        <![endif]-->
<!--
       <div class='contenido' align="center" style="padding-top:22px">
       				DOWNLOAD THIS APP FREE AND MORE IN:
            <br/>
<a href="http://juanbarrospazos.blogspot.com.es/" target="_blank" style="text-decoration:none" onclick='document.getElementById(&apos;ventana-flotante&apos;).className = &apos;oculto&apos;'>	
  				http://juanbarrospazos.blogspot.com.es/
            </a>
       </div>
</div>
-->
	<div id="Conte">
  <div id="head"> 
  			<span style="font-size:18px">
  							<?php print(strtoupper($head_titulo));?>
            </span>
  	</br>
  			<span style="font-size:12px">
  							<?php print(strtoupper($head_titulo2));?>
            </span>
   </div>

  <div style="clear:both"></div>
   
   <div style="margin-top:4px; margin-bottom: 4px; text-align:center" id="TitTut">
		<font color="#59746A">
					<span id="hora">000000</span>
		</font>
	</div>
	
	<div style="clear:both"></div>
	
					<!-- *************************** -->
<!-- *************************** -->		<!-- *************************** -->
					<!-- *************************** -->
	
<?php
	
				   ////////////////////				   ////////////////////
////////////////////				////////////////////				////////////////////
				 ////////////////////				  ///////////////////

if($_POST['ocultop']){
		if($form_errorsp = validate_formp()){
							show_form2($form_errorsp);
								} else {process_pin();
										} 
						}
	else{show_form2();}

				   ////////////////////				   ////////////////////
////////////////////				////////////////////				////////////////////
				 ////////////////////				  ///////////////////

function process_pin(){
	
			global $phppin;
			$phppin = $_POST['pin'];
			global $redir;
			$redir = "<script type='text/javascript'>
							function redir(){
							window.location.href='../indexqr.php?pin='+$phppin;
						}
						setTimeout('redir()',1000);
						</script>";
			print ($redir);
}

				   ////////////////////				   ////////////////////
////////////////////				////////////////////				////////////////////
				 ////////////////////				  ///////////////////

function validate_formp(){
	
	global $db;
	global $db_name;
	
	$sqlp =  "SELECT * FROM `$db_name`.`admin` WHERE `admin`.`dni` = '$_POST[pin]' ";
	$qp = mysqli_query($db, $sqlp);
	$cp = mysqli_num_rows($qp);
	
	$errorsp = array();
	
	if (strlen(trim($_POST['pin'])) == 0){
		$errorsp [] = "PIN: Campo obligatorio.";
		}

	elseif (strlen(trim($_POST['pin'])) < 8){
		$errorsp [] = "PIN: Incorrecto.";
		}

	elseif (strlen(trim($_POST['pin'])) > 8){
		$errorsp [] = "PIN: Incorrecto.";
		}

	elseif (!preg_match('/^[A-Z\d]+$/',$_POST['pin'])){
		$errorsp [] = "PIN: Incorrecto.";
		}
	
	/*
	elseif (!preg_match('/^[^a-z@´`\'áéíóú#$&%<>:"·\(\)=¿?!¡\[\]\{\};,\/:\.\*]+$/',$_POST['pin'])){
		$errors [] = "PIN: Incorrecto.";
		}

	elseif (!preg_match('/^[^a-z]+$/',$_POST['pin'])){
		$errors [] = "PIN: Incorrecto.";
		}*/
	
	elseif($cp == 0){
		$errorsp [] = "PIN: Incorrecto.";
		}

	return $errorsp;

		}

				   ////////////////////				   ////////////////////
////////////////////				////////////////////				////////////////////
				 ////////////////////				  ///////////////////

function show_form2($errorsp=''){
	
	if($_POST['pin']){
		$defaults = $_POST;
		} else {$defaults = array ('pin' => '');}
	
	if ($errorsp){
		

		print("	<div  class='errorscam'>
			<embed src='../audi/pin_error.mp3' autostart='true' loop='false' width='0' height='0' hidden='true'></embed>
					<table align='left' style='border:none'>
					<tr>
					<td style='text-align:left'>
					<!--
					<font color='#FF0000'>* SOLUCIONE ESTOS ERRORES:</font><br/>
					-->
					<font color='#FF0000'>ERROR ACCESO PIN</font>
					</td>
					</tr>
					<!--
					<tr>
					<td style='text-align:left'>
					-->
					");
		/*	
		for($a=0; $c=count($errorsp), $a<$c; $a++){
			print("<font color='#FF0000'>**</font>  ".$errorsp [$a]."<br/>");
			}
		*/
		print("<!--</td>
				</tr>-->
				</table>
				</div>
				<div style='clear:both'></div>");
		}
	
	print("<div style='clear:both'></div>
			
			<table align='center' style=\"margin-top:2px; margin-bottom:2px\" >
				<tr>
					<td>	
						SU PIN
					</td>
					
		<form name='pin' method='post' action='$_SERVER[PHP_SELF]'>	
		
					<td valign='middle'>
		<input type='Password' name='pin' size=12 maxlength=9 value='".$defaults['pin']."' />
					</td>
					<td valign='middle' align='right' colspan='2'>
						<input type='submit' value='FICHAR CON PIN' />
						<input type='hidden' name='ocultop' value=1 />
		</form>	
					</td>
				</tr>
				
			</table>"); 
	
	}

				   ////////////////////				   ////////////////////
////////////////////				////////////////////				////////////////////
				 ////////////////////				  ///////////////////

	?>
	
 					<!-- *************************** -->
<!-- *************************** -->		<!-- *************************** -->
					<!-- *************************** -->
	
 <div id="Caja2Admin" style="text-align: center">
	  
   	<div style="margin-top:4px; margin-bottom: 4px; text-align:center">
		<a href="../index.php">CANCELAR Y VOLVER AL INICIO.</a>
	</div>
	
					<!-- *************************** -->
<!-- *************************** -->		<!-- *************************** -->
					<!-- *************************** -->
	
	
					<!-- *************************** -->
<!-- *************************** -->		<!-- *************************** -->
					<!-- *************************** -->
	
	
	<div>
		<!-- IMPRIME EL VALOR DEL ESCANEO PERO
			LO PASAMOS GET EN EL METODO WINDOW.LOCATION.HREF -->
		<span id="dbr"></span>
	</div>
	
  <div class="select" style="padding-bottom: 4px">
    	<label for="videoSource">V. SOURCE: </label>
	  	<select id="videoSource"></select>
  </div>
	 
	<div style="clear:both"></div>	
	 
  <button id="go" style="font-size: 14px;">PLAY SCANNER QR CODE</button>
	 
	<div style="clear:both"></div>
	 
  <div >
   <!-- <video class='camara' muted autoplay id="video" playsinline="true"></video>
	-->
    <video muted autoplay id="video" playsinline="true"  style="width: 433px; height: 324px; padding-top: 8px"></video>
	
	<!-- DEFINIENDO EL VALOR A 0 OCULTO LA VENTANA DE CAPTURA -->
   	<!-- <canvas id="pcCanvas" width="640" height="480" style="display: none; float: bottom;"></canvas> -->
   	<canvas id="pcCanvas" width="0" height="0" style="display: none; float: bottom;"></canvas>
   	<!-- <canvas id="mobileCanvas" width="240" height="320" style="display: none; float: bottom;"></canvas> -->
	<canvas id="mobileCanvas" width="0" height="0" style="display: none; float: bottom;"></canvas>
  </div>

	  
					<!-- *************************** -->
<!-- *************************** -->		<!-- *************************** -->
					<!-- *************************** -->
	
	
					<!-- *************************** -->
<!-- *************************** -->		<!-- *************************** -->
					<!-- *************************** -->
	
	  
</div>
  
<div style="clear:both"></div>

</div>

<!-- Inicio footer -->
<div id="footer"><?php print($head_footer);?></div>
<!-- Fin footer -->

</body>


					<!-- *************************** -->
<!-- *************************** -->		<!-- *************************** -->
					<!-- *************************** -->
	
	
					<!-- *************************** -->
<!-- *************************** -->		<!-- *************************** -->
					<!-- *************************** -->
	
<script async src="zxing.js"></script>
<script src="video.js"></script>

					<!-- *************************** -->
<!-- *************************** -->		<!-- *************************** -->
					<!-- *************************** -->
	
	
					<!-- *************************** -->
<!-- *************************** -->		<!-- *************************** -->
					<!-- *************************** -->
	
</html>
