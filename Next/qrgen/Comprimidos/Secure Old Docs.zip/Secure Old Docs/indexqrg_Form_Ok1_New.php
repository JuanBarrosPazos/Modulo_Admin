<?php    
    
	session_start();

	//require '../Inclu/error_hidden.php';
	require '../Inclu/Admin_Inclu_01b.php';
	require '../Inclu/mydni.php';
	require '../Inclu/nemp.php';

	require '../Conections/conection.php';
	require '../Conections/conect.php';

	require '../Inclu/Master_Index_Qrgen.php';

						//////////////////////////////
//////////////////////////////				//////////////////////////////
					//////////////////////////////
	
	global $num;
	$num=count(glob("temp/{*}",GLOB_BRACE));
	if($num > 1){ deletemp(); } else { }

	global $num2;
	$num2=count(glob("qrimg/{*}",GLOB_BRACE));
	if($num2 >= ($_SESSION['nuser']*2+6)){ deleqrimg(); } else { }
	//print($_SESSION['nuser']);

	if($_POST['delete']){ delete(); }

	if($_POST['oculto']){
		if($form_errors = validate_form()){
									show_form($form_errors);
									listfiles();
				} else {process_form();
						qrimg();
						show_form();
						listfiles();
							}	
	} else {qrimg();
			show_form();
			listfiles();	
				}

						//////////////////////////////
//////////////////////////////				//////////////////////////////
					//////////////////////////////

function process_form(){

    //set it to writable location, a place for temp generated PNG files
    $PNG_TEMP_DIR = dirname(__FILE__).DIRECTORY_SEPARATOR.'temp'.DIRECTORY_SEPARATOR;
    
	//html PNG location prefix
	global $PNG_WEB_DIR;
    $PNG_WEB_DIR = 'temp/';

	include "phpqrcode.php";    
    
    //ofcourse we need rights to create temp dir
    if (!file_exists($PNG_TEMP_DIR))
        mkdir($PNG_TEMP_DIR);
	
	global $filename;
    $filename = $PNG_TEMP_DIR.'test.png';
    
    //processing form input
	//remember to sanitize user input in real-life solution !!!
	global $errorCorrectionLevel;
    $errorCorrectionLevel = 'L';
    if (isset($_REQUEST['level']) && in_array($_REQUEST['level'], array('L','M','Q','H')))
        $errorCorrectionLevel = $_REQUEST['level'];    

	global $matrixPointSize;
    $matrixPointSize = 4;
    if (isset($_REQUEST['size']))
        $matrixPointSize = min(max((int)$_REQUEST['size'], 1), 10);

    if (isset($_REQUEST['data'])) { 
    
        //it's very important!
        if (trim($_REQUEST['data']) == '')
            die('data cannot be empty! <a href="?">back</a>');
            
        // user data
       $filename = $PNG_TEMP_DIR.'test'.md5($_REQUEST['data'].'|'.$errorCorrectionLevel.'|'.$matrixPointSize).'.png';
       QRcode::png($_REQUEST['data'], $filename, $errorCorrectionLevel, $matrixPointSize, 2); 
		
		if(strlen(trim($_POST['imgname'])) == 0){
			global $imgname;
			$imgname = "pin=".substr($_POST['data'],-8);
			if(file_exists("qrimg/".$imgname.".png")){unlink("qrimg/".$imgname.".png");}else{}
			if(file_exists($filename)){copy($filename, "qrimg/".$imgname.".png");}else{}
			}
			else{ global $imgname;
				  $imgname = str_replace(' ', '_',$_POST['imgname']);
				  if(file_exists("qrimg/".$imgname.".png")){unlink("qrimg/".$imgname.".png");}else{}
				  if(file_exists($filename)){copy($filename, "qrimg/".$imgname.".png");}else{}
					}
 
    } else {    
    
        //default data
   /*
   echo 'You can provide data in GET parameter: <a href="?data=like_that">like that</a><hr/>'; 
   */   
        QRcode::png('PHP QR Code :)', $filename, $errorCorrectionLevel, $matrixPointSize, 2); 
     
    	}    

}

						//////////////////////////////
//////////////////////////////				//////////////////////////////
					//////////////////////////////

function validate_form(){
	
	$errors = array();

	if(strlen(trim($_POST['data'])) == 0){
		$errors [] = "HOST: <font color='#FF0000'> es obligatorio.</font>";
		}
	
	return $errors;

} 

						//////////////////////////////
//////////////////////////////				//////////////////////////////
					//////////////////////////////

function qrimg(){
	global $PNG_WEB_DIR;
	global $filename;
	//display generated file
	print("	<div style='text-align: center'>
				<img src='".$PNG_WEB_DIR.basename($filename)."' />
			</div>
				<hr/>");  
}  

						//////////////////////////////
//////////////////////////////				//////////////////////////////
					//////////////////////////////

function Show_form($errors=''){	

	global $errorCorrectionLevel;
	global $matrixPointSize;

	if(isset($_POST['oculto'])){ $defaults = $_POST;

	} else {
		$defaults = array ( 
		'data' => (isset($_REQUEST['data'])?htmlspecialchars($_REQUEST['data']):'index.php?pin=69696969'),
					);
		}

	if ($errors){
		print("	<table align='center'>
					<tr>
						<th style='text-align:center>
							<font color='#FF0000'>* SOLUCIONE ESTOS ERRORES:</font><br/>
						</th>
					</tr>
					<tr>
						<td style='text-align:left'>");
	for($a=0; $c=count($errors), $a<$c; $a++){
			print("<font color='#FF0000'>**</font>  ".$errors [$a]."<br/>");
			}
	print("</td>
				</tr>
					</table>");
	}

print("<div style='text-align: center'>");

    //config form
    echo '
		<table align="center" style=\"border:0px;margin_bottom:6px;margin-top:10px\">
		<form action="indexqrg.php" method="post">
		<tr>
			<td align="right">
				NAME FOR IMAGE:
			</td>
			<td align="left">
				<input name="imgname" size=32 maxlength=14 value="'.$_POST['imgname'].'" />
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center" class="BorderSup">
       			IF QR AUTO INDEXQR.PHP
	   		</td>
		</tr>
		<tr>
			<td colspan="2" align="center">
				Siempre Relativa: indexqr.php?pin=69696969
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center">
       			IF QR USER DATA CONFIRMATION INDEX.PHP
	   		</td>
		</tr>
		<tr>
			<td colspan="2" align="center" class="BorderInf">
				Siempre Relativa: index.php?pin=69696969
			</td>
		</tr>
		<tr>
			<td align="right">
       			URL DATA FOR QR:
	   		</td>
			<td align="left">
			<input name="data" size=32 maxlength=70 value="'.$defaults['data'].'" />
			</td>
		</tr>
		<tr>
			<td align="right">
		ECC:
			</td>
			<td align="left">
			<select name="level">
				<option value="L"'.(($errorCorrectionLevel=='L')?' selected':'').'>L - smallest</option>
				<option value="M"'.(($errorCorrectionLevel=='M')?' selected':'').'>M</option>
				<option value="Q"'.(($errorCorrectionLevel=='Q')?' selected':'').'>Q</option>
				<option value="H"'.(($errorCorrectionLevel=='H')?' selected':'').'>H - best</option>
			</select>
			<td>
		</tr>
		<tr>
			<td align="right" class="BorderInf">
        SIZE:
			</td>
			<td align="left" class="BorderInf">
			<select name="size">';

	for($i=1;$i<=10;$i++){

		echo '<option value="'.$i.'"'.(($matrixPointSize==$i)?' selected':'').'>'.$i.'</option>';

		}

	print ("</select>
				</td>
			</tr>
			<tr>
				<td colspan=2 align='center'>
						<input type='submit' value='GENERATE QR CODE FOR USER'>
						<input type='hidden' name='oculto' value=1 />
					</form>
				</td>
			</tr>
		</table>
				<hr/>
        
    <!-- 	// benchmark
			//QRtools::timeBenchmark();  
	--> 
		
	</div>");

}

						//////////////////////////////
//////////////////////////////				//////////////////////////////
					//////////////////////////////
	
		function deletemp(){

		global $ruta;
		$ruta = "temp/";
		if(file_exists($ruta)){  $dir = $ruta."/";
									  $handle = opendir($dir);
									  while ($file = readdir($handle))
											 {if (is_file($dir.$file))
												 {unlink($dir.$file);}
											 }
									} else { }
			}

						//////////////////////////////
//////////////////////////////				//////////////////////////////
					//////////////////////////////
	
		function deleqrimg(){

		global $ruta;
		$ruta = "qrimg/";
		if(file_exists($ruta)){  $dir = $ruta."/";
									  $handle = opendir($dir);
									  while ($file = readdir($handle))
											 {if (is_file($dir.$file))
												 {unlink($dir.$file);}
											 }
									} else { }
			}


						//////////////////////////////
//////////////////////////////				//////////////////////////////
					//////////////////////////////
	
function listfiles(){
	
	global $num3;
	$num3=count(glob("qrimg/{*}",GLOB_BRACE));

	global $ruta;
	$ruta ="qrimg/";
	//print("RUTA: ".$ruta.".</br>");
	
	global $rutag;
	$rutag = "qrimg/{*}";
	//print("RUTA G: ".$rutag.".</br>");
		
	$directorio = opendir($ruta);
	global $num;
	$num=count(glob($rutag,GLOB_BRACE));
	if($num < 1){
		
	if ($_POST['delete'] != 1){
		print("<embed src='../audi/no_file.mp3' autostart='true' loop='false' width='0' height='0' hidden='true' ></embed>");
					}
		
		print ("<table align='center' style='border:1; margin-top:2px' width='auto'>
				<tr>
				<td align='center'>NO HAY ARCHIVOS PARA DESCARGAR</td>
				</tr>");
	}else{
		
	if ($_POST['delete'] != 1) {
		print("<embed src='../audi/files_for_exp.mp3' autostart='true' loop='false' width='0' height='0' hidden='true' >
			   </embed>");
						}

	print ("<table align='center' style='border:1; margin-top:2px' width='auto'>
				<tr>
					<td align='center' colspan='3' class='BorderInf'>
						QR CODES FOR EXPORT  ".$num3." 
						<br>
						IF > ".(($_SESSION['nuser']*2+6))." AUTO DELETE QR FILES
					</td>
				</tr>");

while($archivo = readdir($directorio)){
	if($archivo != ',' && $archivo != '.' && $archivo != '..'){
		print("<tr>
					<td class='BorderInfDch'>
						<form name='delete' action='$_SERVER[PHP_SELF]' method='post'>
							<input type='hidden' name='ruta' value='".$ruta.$archivo."'>
							<input type='submit' value='ELIMINAR' >
							<input type='hidden' name='delete' value='1' >
						</form>
					</td>
					<td class='BorderInfDch'>
						<form name='archivos' action='".$ruta.$archivo."' target='_blank' method='post'>
							<input type='submit' value='DESCARGAR'>
						</form>
					</td>
					<td class='BorderInf'>".strtoupper($archivo)."</td>
				</tr>");
			}else{}
		} // FIN DEL WHILE
	}
	closedir($directorio);
	print("</table>");
}

						//////////////////////////////
//////////////////////////////				//////////////////////////////
					//////////////////////////////
					
function delete(){
	unlink($_POST['ruta']);
	print("<embed src='../audi/delete_txt.mp3' autostart='true' loop='false' width='0' height='0' hidden='true' > </embed>");
}
	
						//////////////////////////////
//////////////////////////////				//////////////////////////////
					//////////////////////////////
					
	require '../Inclu/Admin_Inclu_02.php';
	
/* Creado por Juan Barros Pazos 2020 */

?>
