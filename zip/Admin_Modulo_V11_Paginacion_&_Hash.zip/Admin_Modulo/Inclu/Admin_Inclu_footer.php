    <div class="limpiar"></div>
  
</div>

        
<!--
////////////////////////////////
////////////////////////////////
	Fin contenedor de datos.
////////////////////////////////
////////////////////////////////
-->

 
<div style="clear:both"></div>


<!-- Inicio footer -->
<div id="footer"><?php print($head_footer);?></div>
<!-- Fin footer -->

</div>

</body>

</html>