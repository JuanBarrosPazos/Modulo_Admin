
</div>
  
<div style="clear:both"></div>

</div>

<!-- Inicio footer -->
<div id="footer"><?php print($head_footer);?></div>
<!-- Fin footer -->

</body>

</html>
