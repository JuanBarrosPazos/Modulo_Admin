<?php

    global $rutaindex;
    $rutaindex = '../';
    global $rutaadmin;
    $rutaadmin = $rutaindex.'Admin/';
    global $rutabbdd;
    $rutabbdd = $rutaindex.'upbbdd/';
    global $rutacam;
    $rutacam = '';
    global $rutaqrgen;
    $rutaqrgen = $rutaindex.'qrgen/';
    global $rutainclu;
    $rutainclu = $rutaindex.'Inclu/';

?>