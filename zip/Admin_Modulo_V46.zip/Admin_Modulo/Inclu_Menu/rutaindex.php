<?php

    global $rutaindex;
    $rutaindex = '';
    global $rutaadmin;
    $rutaadmin = $rutaindex.'Admin/';
    global $rutabbdd;
    $rutabbdd = $rutaindex.'upbbdd/';
    global $rutacam;
    $rutacam = $rutaindex.'cam/';
    global $rutaqrgen;
    $rutaqrgen = $rutaindex.'qrgen/';
    global $rutainclu;
    $rutainclu = $rutaindex.'Inclu/';

?>