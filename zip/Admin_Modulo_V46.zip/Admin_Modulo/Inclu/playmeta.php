<?php

print("
<meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>
<meta http-equiv='content-type' content='text/html' charset='utf-8' />
<meta http-equiv='Content-Language' content='es-es'>
<meta name='Language' content='Spanish'>
<meta name='description' content='Modulo Administrador' />
<meta name='keywords' content='Juan Barros Pazos, Programas gratis, Spain, Mallorca, Palma de Mallorca' />
<meta name='robots' content='all, index, follow' />
<meta name='audience' content='All' />
<title>Juan Manuel Barros Pazos</title>

<link href='".$rutameta."Css/conta.css' rel='stylesheet' type='text/css' />
<link href='".$rutameta."Css/menu.css' rel='stylesheet' type='text/css' />
<link href='".$rutameta."Css/menuico.css' rel='stylesheet' type='text/css' />

<link href='".$rutameta."Images/favicon.png' type='image/ico' rel='shortcut icon' />
".$meta2.$meta3);

?>