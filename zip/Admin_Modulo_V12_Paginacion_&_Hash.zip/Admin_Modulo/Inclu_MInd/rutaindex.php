<?php

    global $rutaindex;
    $rutaindex = '';
    global $rutaadmin;
    $rutaadmin = 'Admin/';
    global $rutainclu;
    $rutainclu ='Inclu/';

?>