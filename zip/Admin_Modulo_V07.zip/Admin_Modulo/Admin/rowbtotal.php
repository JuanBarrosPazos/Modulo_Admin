<?php

    print(" <input name='id' type='hidden' value='".$rowb['id']."' />
            <input name='ref' type='hidden' value='".$rowb['ref']."' />
            <input name='Nivel' type='hidden' value='".$rowb['Nivel']."' />
            <input name='Nombre' type='hidden' value='".$rowb['Nombre']."' />
            <input name='Apellidos' type='hidden' value='".$rowb['Apellidos']."' />
            <input name='myimg' type='hidden' value='".$rowb['myimg']."' />
            <input name='doc' type='hidden' value='".$rowb['doc']."' />
            <input name='dni' type='hidden' value='".$rowb['dni']."' />
            <input name='ldni' type='hidden' value='".$rowb['ldni']."' />
            <input name='Email' type='hidden' value='".$rowb['Email']."' />
            <input name='Usuario' type='hidden' value='".$rowb['Usuario']."' />
            <input name='Password' type='hidden' value='".$rowb['Password']."' />						
            <input name='Direccion' type='hidden' value='".$rowb['Direccion']."' />
            <input name='Tlf1' type='hidden' value='".$rowb['Tlf1']."' />
            <input name='Tlf2' type='hidden' value='".$rowb['Tlf2']."' />
            <input name='lastin' type='hidden' value='".$rowb['lastin']."' />
            <input name='lastout' type='hidden' value='".$rowb['lastout']."' />
            <input name='visitadmin' type='hidden' value='".$rowb['visitadmin']."' />
            <input name='borrado' type='hidden' value='".$rowb['borrado']."' />");
?>