<?php

    $defaults = array ( 'id' => $defaults['id'],
						'ref' => $defaults['ref'],
						'Nombre' => $defaults['Nombre'],
						'Apellidos' => $defaults['Apellidos'],
						'myimg' => $defaults['myimgcl'],
						'Nivel' => $defaults['Nivel'],			
						'doc' => $defaults['doc'],
						'dni' => $defaults['dni'],
						'ldni' => $defaults['ldni'],
						'Email' => $defaults['Email'],
						'Usuario' => $defaults['Usuario'],
						'Usuario2' => $defaults['Usuario'],
						'Password' => $defaults['Pass'],
						'Password2' => $defaults['Pass'],
						'Direccion' => $defaults['Direccion'],
						'Tlf1' => $defaults['Tlf1'],
						'Tlf2' => $defaults['Tlf2']);

?>