<?php

$defaults = array ( 'Nombre' => '',
					'Apellidos' => '',
					'Nivel' => '',
					'ref' => '',
					'doc' => '',
					'dni' => '',
					'ldni' => '',
					'Email' => 'Solo letras minúsculas',
					'Usuario' => '',
					'Usuario2' => '',
					'Password' => '',
					'Password2' => '',
					'Direccion' => '',
					'Tlf1' => '',
					'Tlf2' => '');
?>