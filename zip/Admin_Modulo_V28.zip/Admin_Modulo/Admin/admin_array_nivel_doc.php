<?php

	$Nivel = array ('' => 'NIVEL USUARIO',
					'admin' => 'ADMINISTRADOR',
					'plus' => 'USER PLUS',
					'user'  => 'USER',
					'close'  => 'CLOSE', );														

  $doctype = array ('DNI' => 'DNI/NIF Espa&ntilde;oles',
						'NIE' => 'NIE/NIF Extranjeros',
					'NIFespecial' => 'NIF Persona F&iacute;sica Especial',
					/*
					'NIFsa' => 'NIF Sociedad An&oacute;nima',
					'NIFsrl' => 'NIF Sociedad Responsabilidad Limitada',
					'NIFscol' => 'NIF Sociedad Colectiva',
					'NIFscom' => 'NIF Sociedad Comanditaria',
					'NIFcbhy' => 'NIF Comunidad Bienes y Herencias Yacentes',
					'NIFscoop' => 'NIF Sociedades Cooperativas',
					'NIFasoc' => 'NIF Asociaciones',
					'NIFcpph' => 'NIF Comunidad Propietarios Propiedad Horizontal',
					'NIFsccspj' => 'NIF Sociedad Civil, con o sin Personalidad Juridica',
					'NIFee' => 'NIF Entidad Extranjera',
					'NIFcl' => 'NIF Corporaciones Locales',
					'NIFop' => 'NIF Organismo Publico',
					'NIFcir' => 'NIF Congragaciones Instituciones Religiosas',
					'NIFoaeca' => 'NIF Organos Admin Estado y Comunidades Autonomas',
					'NIFute' => 'NIF Uniones Temporales de Empresas',
					'NIFotnd' => 'NIF Otros Tipos no Definidos',
					'NIFepenr' => 'NIF Establecimientos Permanentes Entidades no Residentes',
					*/
				);

?>