<?php

    $defaults = array ( 'id' => $_POST['id'],
						'ref' => $_POST['ref'],
						'Nivel' => $_POST['Nivel'],
						'Nombre' => $_POST['Nombre'],
						'Apellidos' => $_POST['Apellidos'],
						'myimg' => $_POST['myimg'],
						'doc' => $_POST['doc'],
						'dni' => $_POST['dni'],
						'ldni' => $_POST['ldni'],
						'Email' => $_POST['Email'],
						'Usuario' => $_POST['Usuario'],
						'Password' => $_POST['Password'],
						'Pass' => $_POST['Pass'],
						'Direccion' => $_POST['Direccion'],
						'Tlf1' => $_POST['Tlf1'],
						'Tlf2' => $_POST['Tlf2'],
						'lastin' => $_POST['lastin'],
						'lastout' => $_POST['lastout'],
						'visitadmin' => $_POST['visitadmin'],
						'borrado' => $_POST['borrado'],);
?>