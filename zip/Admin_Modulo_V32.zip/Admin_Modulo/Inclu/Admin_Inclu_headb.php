<!DOCTYPE html>
	
<head>
	
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="content-type" content="text/html" charset="utf-8" />
<meta http-equiv="Content-Language" content="es-es">
<meta name="Language" content="Spanish">
<meta name="description" content="Modulo Administrador" />
<meta name="keywords" content="Juan Barros Pazos, Programas gratis, Spain, Mallorca, Palma de Mallorca" />
<meta name="robots" content="all, index, follow" />
<meta name="audience" content="All" />
<title>Juan Manuel Barros Pazos</title>
	
<link href="Css/conta.css" rel="stylesheet" type="text/css" />
<link href="Css/menu.css" rel="stylesheet" type="text/css" />
<link href="Css/menuico.css" rel="stylesheet" type="text/css" />

<script src="MenuVertical/SpryMenuBar.js" type="text/javascript"></script>
<link href="MenuVertical/SpryMenuBarVertical.css" rel="stylesheet" type="text/css" />
<script src="Scripts/swfobject_modified.js" type="text/javascript"></script>

<link href="Images/favicon.png" type='image/ico' rel='shortcut icon' />

</head>

<body topmargin="0">
<div id="Conte">

  <div id="head"> 
  			<span style="font-size:18px">
			  		JUAN BARROS PAZOS
            </span>
  	</br>
  			<span style="font-size:12px">
			  	Design & Programming in Palma de Mallorca
            </span>
   </div>

  				<div style="clear:both"></div>
   
<!--
////////////////////////////////
////////////////////////////////
	Inicio contenedor de datos.
////////////////////////////////
////////////////////////////////
-->

  <div id="Caja2Admin">


