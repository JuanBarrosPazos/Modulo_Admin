<?php
session_start();

	require '../Inclu/error_hidden.php';
	require '../Inclu/Admin_head.php';
	require '../Inclu/mydni.php';
	require '../Inclu/nemp.php';
	require '../Conections/conection.php';
	require '../Conections/conect.php';
	require '../Inclu/my_bbdd_clave.php';

	require 'Admin_Crear_Funciones.php';

	require 'Admin_Crear_Logica.php';

	require '../Inclu/Admin_Inclu_footer.php';

				   ////////////////////				   ////////////////////
////////////////////				////////////////////				////////////////////
				 ////////////////////				  ///////////////////
		
/* Creado por Juan Barros Pazos 2021 */
?>
