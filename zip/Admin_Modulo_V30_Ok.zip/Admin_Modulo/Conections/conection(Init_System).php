<?php

$db_host = '127.0.0.1'; 
$db_user = 'user'; 
$db_pass = 'Pass'; 
$db_name = 'bbdd_name'; 
?>