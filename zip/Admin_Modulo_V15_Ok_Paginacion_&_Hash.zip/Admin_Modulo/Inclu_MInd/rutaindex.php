<?php

    global $rutaindex;
    $rutaindex = '';
    global $rutaadmin;
    $rutaadmin = $rutaindex.'Admin/';
    global $rutainclu;
    $rutainclu = $rutaindex.'Inclu/';

?>