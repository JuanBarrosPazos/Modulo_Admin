<?php

    global $rutaindex;
    $rutaindex = '../';
    global $rutaadmin;
    $rutaadmin = '';
    global $rutainclu;
    $rutainclu ='../Inclu/';

?>