<?php
session_start();

	global $docs;
	$docs = 1;
	
	require '../Inclu/error_hidden.php';
	require '../Inclu/Admin_head.php';
	require '../Conections/conection.php';
	require '../Conections/conect.php';
	require '../Inclu/my_bbdd_clave.php';

	require 'Admin_Modificar_img_Funciones.php';

	require 'Admin_Modificar_img_Logica.php';

	require '../Inclu/Admin_Inclu_footer.php';


/* Creado por Juan Barros Pazos 2021 */
?>