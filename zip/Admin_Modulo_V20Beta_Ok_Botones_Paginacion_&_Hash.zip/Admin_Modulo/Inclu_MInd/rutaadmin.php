<?php

    global $rutaindex;
    $rutaindex = '../';
    global $rutaadmin;
    $rutaadmin = '';
    global $rutabbdd;
    $rutabbdd = $rutaindex.'upbbdd/';
    global $rutainclu;
    $rutainclu = $rutaindex.'Inclu/';

?>