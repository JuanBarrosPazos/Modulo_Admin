<?php

    global $rutaindex;
    $rutaindex = '../';
    global $rutaadmin;
    $rutaadmin = $rutaindex.'Admin/';
    global $rutabbdd;
    $rutabbdd = '';
    global $rutainclu;
    $rutainclu = $rutaindex.'Inclu/';

?>