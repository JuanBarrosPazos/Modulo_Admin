<?php

    global $rutaindex;
    $rutaindex = '';
    global $rutaadmin;
    $rutaadmin = $rutaindex.'Admin/';
    global $rutabbdd;
    $rutabbdd = $rutaindex.'upbbdd/';
    global $rutainclu;
    $rutainclu = $rutaindex.'Inclu/';

?>