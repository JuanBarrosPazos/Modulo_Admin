<?php

print ("
<div style='clear:both'></div>

<div class='MenuVertical'>

<section class='app'>

<aside class='sidebar'>

	<header>
".$_SESSION['Nombre'][0].". ".$_SESSION['Apellidos']."</br>
 Level: ".$niv.".</br>
 <a href='#'><i class='ic icoh'></i>
		<span style='color:#FFFFFF;vertical-align:middle'>MENU APP</span>
 </a>
    </header>
    ");
    
?>